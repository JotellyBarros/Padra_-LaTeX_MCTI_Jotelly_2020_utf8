# LaTeX2HTML 2002-2-1 (1.70)
# Associate internals original text with physical files.


$key = q/cite_abnt-classe-doc++YEAR/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/estilos/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-classe-doc++EXPL/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR14724:2001++IMPL/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/opcoes/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/opcoes-ordem/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR14724:2001++YEAR/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-classe-doc/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/textos/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-classe-doc++IMPL/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR14724:2001/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR14724:2001++EXPL/;
$ref_files{$key} = "$dir".q|tabela-simbolos-doc.html|; 
$noresave{$key} = "$nosave";

1;

