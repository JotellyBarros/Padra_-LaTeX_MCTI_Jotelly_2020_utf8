# LaTeX2HTML 2002-2-1 (1.70)
# Associate internals original text with physical files.


$key = q/cite_10520:5.1.5c/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.4-99/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.4-00/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.5ab/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.5a/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.3b/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Abreu/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/mult-ref/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.8/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Deng00/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR10520:2001/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.1-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.4-98/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.1-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR6023:2002/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR10520:2002/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-bibtex-doc/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/mult-abc/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-7/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.1-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.2.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.3a/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.3.2-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.3-1b/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-opcoes/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.5b/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.1.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-8/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Evans/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-9/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR10520:1988/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.2-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR6023:2000/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.8.1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

1;

