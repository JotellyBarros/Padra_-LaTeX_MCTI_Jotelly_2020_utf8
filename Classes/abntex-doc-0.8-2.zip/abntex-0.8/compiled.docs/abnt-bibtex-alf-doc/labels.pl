# LaTeX2HTML 2002-2-1 (1.70)
# Associate labels original text with physical files.


$key = q/cite_10520:5.1.5c/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.3-1/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.2-2/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.4-99/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.2-1/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.4-00/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-5/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.5ab/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.5a/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.3b/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Abreu/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-3/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/mult-ref/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.8/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Deng00/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR10520:2001/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.1-3/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-6/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.4-98/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.1-2/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR6023:2002/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR10520:2002/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-bibtex-doc/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/mult-abc/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-7/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.1-1/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.2.2-2/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-2/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.3a/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-1/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.3.2-3/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.3-1b/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-4/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-opcoes/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:5.1.5b/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.1.2-1/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-8/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.2/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Evans/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520-2002:6.3-9/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR10520:1988/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.2-3/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR6023:2000/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_10520:4.8.1/;
$external_labels{$key} = "$URL/" . q|abnt-bibtex-alf-doc.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.70)
# labels from external_latex_labels array.


$key = q/mult-abc/;
$external_latex_labels{$key} = q|2.2.8|; 
$noresave{$key} = "$nosave";

$key = q/tabela-opcoes/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/mult-ref/;
$external_latex_labels{$key} = q|2.2.7|; 
$noresave{$key} = "$nosave";

1;

