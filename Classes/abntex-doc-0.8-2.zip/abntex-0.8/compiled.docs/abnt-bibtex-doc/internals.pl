# LaTeX2HTML 2002-2-1 (1.70)
# Associate internals original text with physical files.


$key = q/cite_7.5.1.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.5.4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_9.2.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.10-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.9-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.11.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.2.4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ABNT-barcelos0/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.4.5-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-titlecommand/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.1.2-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ABNT-final/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.1-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.9-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.6.5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-subtitle/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_9.1-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.8-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.10-5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-repeated-author-omit_yes/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.11.1-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-opcoes-formatacao/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.4-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-fis/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-9/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-opcoes-url/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/section-quando-vale/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_9.2.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.3-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-9/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.2.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.1-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Giraffa:1999/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-options3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.4-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-options0/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.12.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.12.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-campos-teses/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR10520:2001/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.1.3-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.3-5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-8/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-4b/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.8-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-2:end/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.2.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.10-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.8.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Chiao00/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.1.2-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-options5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.7.1-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-opcoes-funcionamento/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.7-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.1-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-url/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.10-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.6.1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_9.2.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_9.1-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-9/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.4-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.2.1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.3.2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.1-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.2.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.1.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.1.3-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.7.6-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Subramaniam98/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.1.3-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Koneman99/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.1.3-9/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Singh91:Intentions/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-options4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Valiant95:Rationality/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-9b/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.1.3-7/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.4.1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Eiter99:HAA/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.4-1b/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.12.2-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-repeated-title-omit_yes/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.10-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.11.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.3-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.11.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.2.1-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Bumgardner97:Syd/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.1.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.2.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/table-entrada/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ferber95:SMA/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.4.5-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.3.2-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.7.3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.1.2-6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.1.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.1.2-5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.6.4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-7/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.7.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-options1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.10-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.7.1-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.1.3-5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.4-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-bibtex-alf-doc/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.4-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.8-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.10-5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Sun99/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.5.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.1.3-10/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.5.1-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.4-1c/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.11.1-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.1-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.2.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.4.4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-repeated-title-omit_no/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.2.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Tsen86/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.3-1b/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.2.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-opcoes-etal/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Mccarthy92:Elephant/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.2.1-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.3.1-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.10-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.8.3-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.4-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.2.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.11.3-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.4-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.10-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.7.6-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-12/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.6.3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-subestilos/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-8/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-isbn/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.2.6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/sec-teses/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.7.5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.3.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-8/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.2.1-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-11/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.7.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_9.2.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.5.1-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.11.1-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.3-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.1.3-8/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-url/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ABNT-barcelos1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.2.2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/chapter-opcoes-estilo/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.1.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-11/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.1.2-7/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.5.3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Cardona82/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-conf/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.8.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.6.9-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.2.2-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.2.2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Creci99/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.11.1-5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.1.3-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.4-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.3.2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.1.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.3.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/nome-pessoais/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.1.3-6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.3-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Deng00/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.1-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.3-6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-opcoes-composicao/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.6.6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.2.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.2.1-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.3.2b/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-acentos/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.5.5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.6.8-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.8-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.10-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.2.2-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-2:begin/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.11.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.6.7/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.10-6/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.7.4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-7/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR6023:2000/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.3.1-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-options2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Inverno97:Formalisms/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-10/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-7/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_DOI/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.5-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.6.2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.11.1-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-versao-normas/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.1-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/tabela-type/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.2.1-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.1.3-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.7.2.2-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.5.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.4-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.4.3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.6.8-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.5.2-1:end/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.5.2-1:begin/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.7-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.4.2.3-5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-5b/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.2.5/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.1.1.7-2/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.5.1.2-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.13.2-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NBR10520:1988/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Jennings98:Applications/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.7.1-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abnt-repeated-author-omit_no/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-3/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_7.9.3-4/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_8.11.2-1/;
$ref_files{$key} = "$dir".q|abnt-bibtex-doc.html|; 
$noresave{$key} = "$nosave";

1;

